<?php

namespace Mpdf\Tag;

class P extends BlockTag
{


}
