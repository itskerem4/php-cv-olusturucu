<?php

namespace Mpdf\Tag;

class SetHtmlPageHeader extends SetHtmlPageFooter
{


}
