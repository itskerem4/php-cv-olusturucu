<?php

namespace Mpdf\Tag;

class Main extends BlockTag
{


}
